<div class="container-fluid mt-2">
    <div class="row justify-content-md-center text-info">
        <div class="col-md-6 offset-md-3 bg-white pb-4 pt-2">
            <div id="banner">
                <div class="row mb-3">
                    <div class="col">
                        <div id="carouselExampleIndicators" class="carousel slide mt-1" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="<?php echo base_url('assets/img/'); ?>Rasuk_2_Msite.jpg" alt="First slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="<?php echo base_url('assets/img/'); ?>Headline-Msite_Mtix-_indomaret.jpg" alt="Second slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="<?php echo base_url('assets/img/'); ?>Rasuk_2_Msite.jpg" alt="Third slide">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div id="content">
                <!-- <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card-deck text-center">
                            <div class="card">
                                <a href="<?php echo base_url('Details_movie') ?>">
                                    <img class="card-img-top" src="https://media.21cineplex.com/webcontent/gallery/pictures/157657443570473_287x421.jpg" alt="Card image cap">
                                    <div class="card-body">
                                        <h5 class="card-title">Card title</h5>

                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-deck text-center">
                            <div class="card">
                                <a href="<?php echo base_url('Details_movie') ?>">
                                    <img class="card-img-top" src="https://media.21cineplex.com/webcontent/gallery/pictures/157657443570473_287x421.jpg" alt="Card image cap">
                                    <div class="card-body">
                                        <h5 class="card-title">Card title</h5>

                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-deck text-center">
                            <div class="card">
                                <a href="<?php echo base_url('Details_movie') ?>">
                                    <img class="card-img-top" src="https://media.21cineplex.com/webcontent/gallery/pictures/157657443570473_287x421.jpg" alt="Card image cap">
                                    <div class="card-body">
                                        <h5 class="card-title">Card title</h5>

                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> -->
                <?php $i = 0;
                foreach ($movies as $dt) {
                    if (($i % 3) == 0) { ?>
                        <div class="row mb-2">
                            <div class="col-md-4">
                                <div class="card-deck text-center">
                                    <div class="card">
                                        <a href="<?php echo site_url('Details_movie/get_data/').$dt->id_film ?>">                                          
                                            <img class="card-img-top" src="<?= $dt->poster ?>" alt="Card image cap">
                                            <div class="card-body">
                                                <h5 class="card-title"><?= $dt->judul_film ?></h5>

                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php } else if ((($i % 3) == 1) || (($i % 3) == 2)) { ?>
                            <div class="col-md-4">
                                <div class="card-deck text-center">
                                    <div class="card">
                                        <a href="<?php echo site_url('Details_movie/get_data/').$dt->id_film ?>">                                          
                                            <img class="card-img-top" src="<?= $dt->poster ?>" alt="Card image cap">
                                            <div class="card-body">
                                                <h5 class="card-title"><?= $dt->judul_film ?></h5>

                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php }
                    if ((count($movies) - 1 == $i) || (($i % 3) == 2)) { ?>
                        </div>
                    <?php } ?>

                <?php $i++;
                } ?>


            </div>





        </div>


        <div class="col-md-3"></div>
        <!-- <div class="col-md-auto">
        Variable width content
      </div>
      <div class="col col-lg-2">
        3 of 3
      </div> -->
    </div>
</div>
<footer class="container mt-2">
    <p style="text-align: center;">&copy; 2020 Nur Hadli </p>
</footer>
<script type="text/javascript" src="<?php echo base_url('assets/'); ?>jquery/jquery-3.4.1.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script>
    var site = '<?php echo base_url() ?>';
    $(document).ready(function() {

    })

    function login() {
        var username = $('#input_username').val();
        var password = $('#input_password').val();
        var dt = {
            username: username,
            password: password
        };

        $.ajax({
            type: 'POST',
            url: site + 'Auth/login',
            dataType: 'json',
            data: dt,

            success: function(respon) {
                if (respon.status == 'sukses') {
                    alert(respon.pesan);
                    return location.reload();
                } else {
                    $("#input_password").focus();
                    alert(respon.pesan);
                    // return location.reload();
                }
            }
        })
    }
   
</script>



</body>

</html>