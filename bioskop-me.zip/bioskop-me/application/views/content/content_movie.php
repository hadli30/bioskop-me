<div class="container-fluid mt-2">
  <div class="row justify-content-md-center text-info">
    <div class="col-md-6 offset-md-3 bg-white pb-4 pt-2">
      <?php foreach ($detail_film as $dt) { ?>
        <div id="header-form">
          <div class="row">
            <div class="col-md-2">
              <img src="<?php echo base_url('assets/img/').$dt->icon; ?>" alt="Card image cap">
            </div>
            <div class="col text-dark">
              <p class="font-weight-bold"><?= $dt->judul_film ?></p>
              <p><?= $dt->genre ?></p>
            </div>
          </div>
          <hr />
          <div id="body-form">
            <div class="row">
              <div class="col-md-4">
                <img class="w-100" src="<?= $dt->poster ?>" alt="Card image cap">
              </div>
              <div class="col-md-6 text-dark">
                <p>Durasi: <?= $dt->durasi ?></p>
                <button type="button" class="btn btn-primary btn-sm mb-2" onclick="buy_tiket()">Buy Ticket</button>
                <input type="hidden" id="id_film2" name="id_film2" value="<?= $dt->id_film ?>">
                <p>Producer:<?= $dt->produser ?></p>
                <p>Director<?= $dt->sutradara ?></p>
                <p>Writer:<?= $dt->penulis ?></p>
                <p>Produksi: <?= $dt->produksi ?></p>
                <p>Cast: <?= $dt->casts ?></p>
              </div>
            </div>
            <div class="row">
              <div class="col text-dark">
                <p><?= $dt->sinopsis ?></p>
              </div>
            </div>
          </div>
        </div>
        <div id="body-from">

        </div>
      <?php } ?>

    </div>


    <div class="col-md-3"></div>

  </div>
</div>
<footer class="container mt-2">
  <p style="text-align: center;">&copy; 2020 Nur Hadli </p>
</footer>


<div class="modal fade" id="ModalTiket" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-info" id="modal_header"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center" id="modal-body">
        <!-- <button type="button" class="btn btn-info btn-sm" onclick="check_bangku('12.00')">12.00</button>
        <button type="button" class="btn btn-info btn-sm" onclick="check_bangku('13.00')">13.00</button>
        <button type="button" class="btn btn-info btn-sm" onclick="check_bangku('14.00')">14.00</button>
        <button type="button" class="btn btn-info btn-sm" onclick="check_bangku('15.00')">15.00</button> -->
      </div>
      <br />
    </div>
  </div>
</div>

<script type="text/javascript" src="<?php echo base_url('assets/'); ?>jquery/jquery-3.4.1.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script>
  var site = '<?php echo base_url() ?>';
  var id_film = $('#id_film2').val();;
  var jadwal_reserved;
  $(document).ready(function() {

  })

  function login() {
    var username = $('#input_username').val();
    var password = $('#input_password').val();
    var dt = {
      username: username,
      password: password
    };

    $.ajax({
      type: 'POST',
      url: site + 'Auth/login',
      dataType: 'json',
      data: dt,

      success: function(respon) {
        if (respon.status == 'sukses') {
          alert(respon.pesan);
          return location.reload();
        } else {
          $("#input_password").focus();
          alert(respon.pesan);
          // return location.reload();
        }
      }
    })
  }

  function buy_tiket() {
    $.ajax({
      type: 'POST',
      url: site + 'Tiket',
      dataType: 'json',
      data: {
        id_film: id_film
      },
      success: function(respon) {
        if (respon.status == 'sukses') {
          $('#modal-body').empty();
          $("#modal-footer").remove();
          $('#modal_header').empty();
          $("#modal_header").append('Pilih Jadwal');
          // $('#modal-footer').empty();
          $('#modal-body').append(respon.dt_modal);
          $('#ModalTiket').modal('show')
          // alert(respon.pesan);
        } else {
          // alert(respon.pesan);
          window.location.href = site + 'Auth';
        }
      }
    })
  }

  function check_bangku(id) {
    jadwal_reserved = id;
    $.ajax({
      type: 'POST',
      url: site + 'Tiket/check_bangku',
      dataType: 'json',
      data: {
        id_film: id_film,
        jadwal: id
      },
      success: function(respon) {
        if (respon.status == 'sukses') {
          $('#modal_header').empty();
          $("#modal_header").append('Pilih Kursi');
          $('#modal-body').empty();
          $("#modal-body").append(`<button type="text" class="btn btn-info btn-sm" disabled>` + id + `</button> <br/><br/>`);
          $("#modal-body").append(respon.dt_kursi);
          $("#modal-body").after(`
              <div class="modal-footer" id='modal-footer'>
                <div class="mx-auto">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="reserved()">Reserved</button>
                </div>
             </div>
          `);
        } else {
          // alert(respon.pesan);

        }
      }
    })
  }

  function reserved() {

    var selecteditems = [];
    var dt = {};

    $("#checkboxes").find("input:checked").each(function(i, ob) {
      selecteditems.push($(ob).val());
    });

    selecteditems.forEach(myFunction);

    function myFunction(item, index) {
      dt['KRS-' + index] = item;
    }

    dt['jadwal'] = jadwal_reserved;
    dt['length'] = selecteditems.length;
    dt['id_film'] = id_film;
    // console.log(dt);
    $.ajax({
      type: 'POST',
      url: site + 'Tiket/reserved',
      dataType: 'json',
      data: dt,
      success: function(respon) {
        if (respon.status == 'sukses') {
          alert(respon.pesan);
          // return location.reload();
        } else {
          alert(respon.pesan);
        }
      }
    })
    // console.log(selecteditems[0]);

  }
</script>



</body>

</html>