<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Model_code extends CI_Model
{
    public function id_pemesanan()
    {
        $q = $this->db->query('SELECT MAX(RIGHT(id_pemesanan,3)) AS kd_max FROM tr_pemesanan');
        $ckq = $q->row();
        $kd = "";
        if ($q->num_rows() > 0 && !empty($ckq->kd_max)) {
            foreach ($q->result() as $k) {
                $tmp = ((int) $k->kd_max) + 1;
                $kd = sprintf("%03s", $tmp);
            }
        } else {
            $kd = "001";
        }
        return "TR" . $kd;
    }

    public function id_tiket()
    {
        $q = $this->db->query('SELECT MAX(RIGHT(id_tiket,3)) AS kd_max FROM tiket');
        $ckq = $q->row();
        $kd = "";
        if ($q->num_rows() > 0 && !empty($ckq->kd_max)) {
            foreach ($q->result() as $k) {
                $tmp = ((int) $k->kd_max) + 1;
                $kd = sprintf("%03s", $tmp);
            }
        } else {
            $kd = "001";
        }
        return "TKT" . $kd;
    }
}
