<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Model_query extends CI_Model
{
    public function get_data_jadwal($id_film)
    {
        $sql = 'select jadwal.jam_mulai from jadwal
        INNER JOIN penayangan
        ON jadwal.id_jadwal = penayangan.id_jadwal
        INNER JOIN studio
        ON penayangan.id_studio = studio.id_studio
        INNER JOIN film
        ON studio.id_film = film.id_film
        where film.id_film = ?';

        return $result = $this->db->query($sql, array($id_film));
    }

    public function get_data_kursi($id_film, $jadwal)
    {
        $sql = 'select kursi.kd_kursi, tiket.id_pemesanan, tiket.id_penayangan, film.judul_film from tiket
        INNER JOIN kursi
        ON tiket.id_kursi = kursi.id_kursi
        INNER JOIN penayangan
        ON tiket.id_penayangan = penayangan.id_penayangan
        INNER JOIN studio
        ON penayangan.id_studio = studio.id_studio
        INNER JOIN jadwal
        ON penayangan.id_jadwal = jadwal.id_jadwal
        INNER JOIN film
        ON studio.id_film = film.id_film
        where film.id_film = ? and jadwal.jam_mulai = ?';

        return $result = $this->db->query($sql, array($id_film, $jadwal));
    }
    public function all_kursi($id_film)
    {
        $sql = 'select kursi.kd_kursi from kursi
        INNER JOIN studio
        ON kursi.id_studio = studio.id_studio
        INNER JOIN film
        ON studio.id_film = film.id_film
        where film.id_film = ? ';
        return $result = $this->db->query($sql, array($id_film));
    }

    public function get_id_penayangan($id_film, $jadwal){
        $sql = 'select penayangan.id_penayangan as id from penayangan
        INNER JOIN jadwal
        ON penayangan.id_jadwal = jadwal.id_jadwal
        INNER JOIN studio
        ON penayangan.id_studio = studio.id_studio
        INNER JOIN film
        ON studio.id_film = film.id_film
        where jadwal.jam_mulai = ? and film.id_film = ?';
        return $result = $this->db->query($sql, array( $jadwal,$id_film));
    }
}
