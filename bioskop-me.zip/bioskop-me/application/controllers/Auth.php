<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Auth extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}
	public function index()
	{
		$this->load->view('login');

	}

	public function login()
	{
		$email = $this->input->post('username');
		$password = $this->input->post('password');
		$user = $this->db->get_where('pemesan', ['email' => $email])->row_array();
		if ($user) {
			if ($password == $user['password']) {
				$data = [
					'id_user'=>$user['id_pemesan'],
					'email' => $user['email'],
					'name' => $user['nama']
				];
				$this->session->set_userdata($data);
				echo json_encode(array('status' => 'sukses', 'pesan' => 'user terdafatar'));
				// hasnt complete
				// if ($user['role_id'] == 1) {
				// } else {
				// 	redirect('Dashboard');
				// }
			} else {
				echo json_encode(array('status' => 'gagal', 'pesan' => 'password salah!!!'));
				// redirect('Auth');
			}
		} else {
			echo json_encode(array('status' => 'gagal', 'pesan' => 'user tidak terdaftar'));
			// redirect('Auth');
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('email');
		redirect('Dashboard');
	}

	// private function _login()
	// {
	// 	$email = $this->input->post('email');
	// 	$password = $this->input->post('password');
	// 	$user = $this->db->get_where('user_details', ['username' => $email])->row_array();
	// 	if ($user) {
	// 		if (password_verify($password, $user['password'])) {
	// 			if ($user['is_active'] == "Active") {
	// 				$data = [
	// 					'email' => $user['username'],
	// 					'name' => $user['name'],
	// 					'role_id' => $user['role_id']
	// 				];
	// 				$this->session->set_userdata($data);
	// 				// hasnt complete
	// 				if ($user['role_id'] == 1) {
	// 					redirect('Dashboard');
	// 				} else {
	// 					redirect('Dashboard');
	// 				}
	// 			} else {
	// 				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email has not activated! Please activate.</div>');
	// 				redirect('Auth');
	// 			}
	// 		} else {
	// 			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong password or username!</div>');
	// 			redirect('Auth');
	// 		}
	// 	} else {
	// 		$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email is not registered! Please Sign up.</div>');
	// 		redirect('Auth');
	// 	}
	// }

	

	public function forgot_password()
	{
		$data['title'] = 'XL-MS IP Adress Manager Reset Password';
		$this->load->view('template/auth_header', $data);
		$this->load->view('auth/forgot_password');
		$this->load->view('template/auth_footer');
	}
	public function registration()
	{
		$this->form_validation->set_rules('name', 'Full Name', 'required|trim');
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.username]', ['is_unique' => 'This email has already registered!']);
		$this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[8]|matches[password2]');
		$this->form_validation->set_rules('password2', 'Repeat Password', 'required|trim|matches[password1]');
		$this->form_validation->set_rules('role', 'Role', 'required');
		if ($this->form_validation->run() == false) {
			$data['title'] = 'XL-MS IP Adress Manager User Registration';
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Harap masukan detail user dengan benar</div>');
			redirect('Admin/user_administrator');
		} else {
			$row = $this->db->select("*")->limit(1)->order_by('id', "DESC")->get("user_details")->row();
			$id =  $row->id + 1;

			$email = $this->input->post('email', true);
			$data = [
				'id' => $id,
				'username' => htmlspecialchars($email),
				'name' => htmlspecialchars($this->input->post('name', true)),
				'image' => 'default.jpg',
				'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
				'role_id' => htmlspecialchars($this->input->post('role', true)),
				'is_active' => 'Active'
			];
			$this->db->insert('user_details', $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Congratulation! Your account has been created. Please Login</div>');
			redirect('Admin/user_administrator');
		}
	}

	
}
