<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tiket extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */

    public  function __construct()
    {
        parent::__construct();
        $this->load->model('Model_query', 'model_query');
        $this->load->model('Model_code', 'model_code');
        date_default_timezone_set('Asia/Jakarta');
    }
    public function index()
    {
        // $data['content'] = 'dashboard_user2';
        // $data['navbar'] = '';
        // if ($this->session->userdata('email') != '') {
        // 	$data['content'] = 'dashboard_user2';
        // 	$data['navbar'] = 'on_login';

        // }
        // $this->load->view('template', $data);
        if ($this->session->userdata('email') != '') {
            $id_film = $this->input->post('id_film');
            $data_jadwal = $this->model_query->get_data_jadwal($id_film)->result_array();
            $data_modal = '';
            // <button type="button" class="btn btn-info btn-sm" onclick="check_bangku('13.00')">13.00</button>

            foreach ($data_jadwal as $rs) {
                $data_modal .= '<button type="button" class="btn btn-info btn-sm mr-2" onclick="check_bangku(\'' . $rs['jam_mulai'] . '\')">' . $rs['jam_mulai'] . '</button>';
            }
            // print_r($data_jadwal);
            // die;
            echo json_encode(array('status' => 'sukses', 'pesan' => 'beli tiket', 'dt_modal' => $data_modal));
        } else {
            echo json_encode(array('status' => 'gagal', 'pesan' => 'belom login!!'));
            //  $this->load->view('login');
        }
    }


    public function check_bangku()
    {
        // $id_film = $this->input->post('id_film');
        // $jadwal = $this->input->post('jadwal');

        // $data_all_kursi = $this->model_query->all_kursi($id_film)->result_array();
        // print_r($data_all_kursi);
        // die;

        $check_box = '<div id="checkboxes">';
        $id_film = $this->input->post('id_film');
        $jadwal = $this->input->post('jadwal');
        $data_all_kursi = $this->model_query->all_kursi($id_film)->result_array();
        foreach ($data_all_kursi as $rs) {
            $flag = 0;
            $data_kursi_terbooking = $this->model_query->get_data_kursi($id_film, $jadwal)->result_array();
            foreach ($data_kursi_terbooking as $rs2) {
                if ($rs['kd_kursi'] ==  $rs2['kd_kursi']) {
                    $flag = 1;
                }
            }
            if ($flag == 0) {
                $check_box .= '<div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="' . $rs['kd_kursi'] . '" value="' . $rs['kd_kursi'] . '">
                                 <label class="custom-control-label  text-success" for="' . $rs['kd_kursi'] . '">' . $rs['kd_kursi'] . '</label>
                            </div>';
            } else {
                $check_box .= '<div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="' . $rs['kd_kursi'] . '" disabled>
                                 <label class="custom-control-label text-danger" for="' . $rs['kd_kursi'] . '">' . $rs['kd_kursi'] . '</label>
                            </div>';
            }
        }
        $check_box .= '</div>';
        echo json_encode(array('status' => 'sukses', 'pesan' => 'beli tiket', 'dt_kursi' => $check_box));
    }

    public function reserved()
    {
        $dt = array();
        $username = $this->session->userdata('id_user');
        $length_reserved = $this->input->post('length');
        $id_pemesanan = $this->model_code->id_pemesanan();
        $tanggal_pemesanan = date("Y-m-d H:i:s");

  
        // echo($id_penayangan['id']);
        // print_r($id_penayangan);

        $data_tr_pemesanan = array(
            'id_pemesanan' => $id_pemesanan,
            'jumlah' => $length_reserved,
            'tanggal_pemesanan' => $tanggal_pemesanan,
            'id_pemesan' => $username
        );
        $rs =  $this->db->insert('tr_pemesanan', $data_tr_pemesanan);

        for ($x = 0; $x < $length_reserved; $x++) {
            $id_tiket = $this->model_code->id_tiket();
            $jadwal_film_mulai = $this->input->post('jadwal');
            $id_film = $this->input->post('id_film');
            $id_penayangan = $this->model_query->get_id_penayangan($id_film, $jadwal_film_mulai)->row(0);
            $krs = 'KRS-' . $x;
            $krs = $this->input->post($krs);
            $krs = $this->db->select('id_kursi')->from('kursi')->where('kd_kursi', $krs)->get()->row(0);
            $data_tiket['id_tiket'] = $id_tiket;
            $data_tiket['id_kursi'] = $krs->id_kursi;
            $data_tiket['id_pemesanan'] = $id_pemesanan;
            $data_tiket['id_penayangan'] = $id_penayangan->id;
            $insert_tiket = $this->db->insert('tiket', $data_tiket);
        }
        if($insert_tiket){
            // $rs =  $this->db->insert('tr_pemesanan', $data_tr_pemesanan);
            echo json_encode(array('status' => 'sukses', 'pesan' => 'Reserved berhasil'));
        }else{
            echo json_encode(array('status' => 'gagal', 'pesan' => 'Reserved Gagal'));
        }

        // print_r($data);

        //    $rs =  $this->db->insert('tr_pemesanan', $data_tr_pemesanan);

        //    $data_tiket = array(
        //     'id_tiket' => $id_tiket,
        //     // 'id_kursi' => $length_reserved,
        //     'id_pemesanan' => $id_pemesanan,
        //     'id_penayangan'=> $id_penayangan
        // );


        // if($rs){
        //     echo json_encode(array('status' => 'sukses', 'pesan' => 'Reserved berhasil'));
        // }else{
        //     echo json_encode(array('status' => 'gagal', 'pesan' => 'Reserved Gagal'));
        // }

        // echo($id_pemesanan);
        // echo('<br/>');       
        
        // print_r($data_tiket);
        // die;
    }
}
